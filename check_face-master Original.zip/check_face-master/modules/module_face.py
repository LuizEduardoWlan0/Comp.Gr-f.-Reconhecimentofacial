import time
import cv2
import sys
import getopt
import tkMessageBox
import asyncore
import random as ale
import numpy as np
import os as systems
from detect_face import *
from takePicture_face import *

i = 0
tam = 0
texto = ""
font = cv2.FONT_HERSHEY_SIMPLEX
