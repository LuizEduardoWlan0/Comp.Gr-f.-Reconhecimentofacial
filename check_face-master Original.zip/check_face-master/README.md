# python_opencv
This project aims to register people by face and register in the database.
I am starting a study on the Python language with Opencv library and mongoDB database.